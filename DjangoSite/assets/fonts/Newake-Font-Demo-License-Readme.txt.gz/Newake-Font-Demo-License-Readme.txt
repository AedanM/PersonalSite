
NEWAKE FONT
by Indieground Design © 2021.
V.2.1


_____________________________________________________________________________


This font is free for PERSONAL USE ONLY.

If you would like to use it commercially, you can buy the license from https://indieground.net/product/newake-font/

Thank you.


_____________________________________________________________________________


info@indieground.net
https://indieground.net

